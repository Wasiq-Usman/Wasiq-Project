base=float(input("Enter base of triangle"))
height=float(input("Enter height of triangle"))
area=0.5*base*height
print(area)
input("Enter any key to exit")