import calendar
year=int(input("Enter year"))
calendar=calendar.calendar(year)
print(calendar)
input("Enter any key to exit")