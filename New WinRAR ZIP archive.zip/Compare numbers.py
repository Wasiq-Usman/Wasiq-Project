n1=float(input("Enter first number"))
n2=float(input("Enter second number"))
if n1>n2:
    print ("First number is greater than second")
else:
    print("second number is greater than first")
input("Enter any key to exit")